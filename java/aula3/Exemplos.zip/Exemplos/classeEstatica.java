package aula3.Exemplos;

public class classeEstatica {
    static double pi = 3.14;
    static int somarInts(int a, int b){
        return a + b;
    }

}
